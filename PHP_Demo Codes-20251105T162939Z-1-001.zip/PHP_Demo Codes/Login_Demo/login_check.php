<?php

$conn=mysqli_connect("localhost","root","","login_demo") or die("connection failed:".mysqli_error());

if(isset($_REQUEST['sub']))
{
$a = $_REQUEST['uname'];
$b = $_REQUEST['upassword'];

$res = mysqli_query($conn,"select* from users where user_id='$a'and user_password='$b'");
$result=mysqli_fetch_array($res);
if($result)
{
	if(isset($_REQUEST["remember"]) && $_REQUEST["remember"]==1)
	setcookie("login","1",time()+60);// seconds on page time 
else
	setcookie("login","1");
	header("location:home_page.php");
	
	
}
else
{
	header("location:login.php?err=1");
	
}
}
?>